
This is a TinnR project.
You have to adjust the paths in the project file ../ZAp.tps to your location
to be able to open it in TinnR.

OS is Windows 7 Professional, version 6.1 (Build 7601 Servicepack 1)
Output of R.Version() is in docs/R_version.txt.




If you are reading this I assume you are trying to help me with building this
package. Some information:

(A) package is not complete, merely intended to illustrate the problems.
(B) I am running R version 3.5.0 with Rcpp built under R 3.5.1
    (could this be the problem?)
    
Unexplained effects:

If I run Rcpp.package.skeleton it generates a file RcppExports.cpp containing
multiple function definitions
(i.e. many functions are written into it more than once).
Run source("R/runPackage.R") to reproduce this after adjusting the path
parameter in the call to Rcpp.package.skeleton in R/runPackage.R.

A copy of the file generated on my machine is in docs/RcppExport_corrupted.cpp

After manually editing RcppExports.cpp (by also adding needed includes,
a copy of this is in docs/) we can get to a point where in

> R CMD check

compilation and linking succeeds and the dll is built. But there is then the
follwing problem:

** R
** byte-compile and prepare package for lazy loading
Reading DataUtils.R
Reading Env.R
Reading Paths.R
Reading StatUtils.R
Reading SynData.R
Warning in file(filename, "r", encoding = encoding) :
  cannot open file 'src/Env.R': No such file or directory
Error in file(filename, "r", encoding = encoding) :
  cannot open the connection
Error : unable to load R code in package 'ZAp'
ERROR: lazy loading failed for package 'ZAp'
* removing 'C:/Users/MeyerM/AppData/Local/Temp/RtmpO6gkfs/ZAp.Rcheck/ZAp'
In R CMD INSTALL


Comments on the C++ code:
(1) All headers protected by include guards
(2) No freestanding functions implemented in headers
    (only class member functions).
    
What is going on here??
    


