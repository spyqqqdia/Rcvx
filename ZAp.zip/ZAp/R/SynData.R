cat("Reading SynData.R\n")


synShift <- 0.005

# Synthetic correlation matrix of size nLibors x nLibors.
#
synRho <- function(nLibors){

    result <- matrix(nrow=nLibors,ncol=nLibors)
    # row(A) is the matrix with the row indices of the elements of the matrix A
    exp(-0.05*abs(row(result)-col(result)))
}

# Synthetic vector of log-Libor volas of size nLibors.
#
synSigma <- function(nLibors) as.vector(rep(0.2,nLibors))

# Synthetic covariance matrix of size nLibors x nLibors
# based on synRho and synSigma.
#
# @return  diag(synSigma(nLibors))*synRho(nLibors)*diag(synSigma(nLibors))
#
synCovMat <- function(nLibors){

   sigma <- synSigma(nLibors)
   mm_bimult_diag(synRho(nLibors),sigma,sigma)
}

# Synthetic principal components (eigenvectors) scaled with sqrt(eigenvalue)
# of the syntehtic covariance matrix synCovMat
#
# @param nPCs number of leading principal compnents, ie. the eigenvectors
# with respect to the largest eigenvalues, must satisfy nPCs <= nLibors.
#
# @return nLibors x nPCs matrix with the nPCs leading eigenvectors in the
# columns.
#
synPC <- function(nLibors,nPCs){

    eig <- eigen(synCovMat(nLibors),symmetric=TRUE)
    eigVecs <- as.matrix(eig$vectors[,1:nPCs])
    eigVals <- as.vector(eig$values[1:nPCs])
    mm_rightmult_diag(eigVecs,eigVals)
}

# Linear from 0 to close to 0.03 then shifted down by synShift.
#
synStartCurve <- function(nLibors) 0.03*(0:(nLibors-1))/nLibors - synShift