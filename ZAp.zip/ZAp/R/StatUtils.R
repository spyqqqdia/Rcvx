cat("Reading StatUtils.R\n")



# Exract the vector of volas for marketID from the Vola_df data frame,
# annualized libors, 1Y step!
#
# @param marketID: BUND_COM, SWAP
#
volasForMarket <- function(marketID){

   volaColNr <- 3    # volas in column 4 are annualized, 1Y step
   res <- volas_df[which(volas_df$riskfactor==marketID),volaColNr]
   rownames(res) <- NULL
   colnames(res) <- NULL
   res
}


# Volas for the entire curve (annualized libors, 1Y step).
#
volasAll <- function(){

   sigma_BUND = volasForMarket("BUND")
   sigma_REAL = volasForMarket("REAL")
   sigma_HVPI = volasForMarket("HVPI")
   as.matrix(c(sigma_BUND, sigma_REAL, sigma_HVPI),ncol=1)
}





# The entire covariance matrix (annualized libors, stepsize = 1Y)
#
getCovMat <- function(){

   sigmas <- matrix(volasAll(),ncol=1)
   mm_bimult_diag(corrMat,sigmas,sigmas)
}



