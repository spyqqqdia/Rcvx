source("R/globals.R")
library(Rcpp)

# setwd("C:/UsrLocal/temp/ZAp")
# source("R/runPackage.R")


# This code produces the package skeleton, especially the transformation
# of the C++ code to C code suited for the .Call interface for all exposed
# C++ functions (file RcppExports.cpp) and R functions calling the same
# (file RcppExports.R) and checks if the package is sound for installation.
#
# The code cannot be packaged into a function (Rcpp.package.skeleton does
# not work from within a function) and must be run from top level.
#
# This process is not perfect.
# For example local headers are not all copied to RcppExports.cpp.
# RcppExports.cpp only contains the oncludes
#
#   #include <Rcpp.h>
#   using namespace Rcpp;
#
# The reason for this is that local types are not usually exposed back to R.
#
# This is a problem if for example one of the C++-functions contains a
# parameter of type std::string ("string not declared in this scope").
# In this case we have to manually add
#
#   #include <string>
#   using std::string;
#
# To the RcppExports.cpp file.
# Likewise all headers which contain an implementation _must_ be included
# in Rcppexports.cpp (by hand) or else we have declared but undefined functions
# resulting in linker errors.
#
# Occasionally functions are written twice to the file RcppExports.cpp.
# This leads to a duplicated definition error.
# These duplicates also have to be eliminated by hand.
#
# In short it is necessary to edit the file RcppExports.cpp by hand to
# eliminate such errors.
# Once this is done we must run
#
#  R> system("R CMD check ../ZA")      or
#  R> devtools::check()
#
# from the R console to check if the package is now ready for
# installation (doCkeckPackage <- TRUE).
# See http://http://r-pkgs.had.co.nz/check.html
#
# We must _not_ run Rcpp.package.skeleton again since this will overwrite the
# RcppExports.cpp files again.
# We only run Rcpp.package.skeleton again if we have new R or cpp files or
# functions signatures have changed.
# Thereafter have to deal with the aforementioned problems in RcppExports.cpp
# again.


# Put the following includes into RcppExports:
#  #include <Rcpp.h>
#  #include <string>
#  #include "utils.hpp"
#  #include "swap.hpp"
#  #include "PathGenerator.hpp"
#  using std::string;
#  using namespace Rcpp;


doMakePackage <- TRUE
doCkeckPackage <- FALSE
doInstallPackage <- FALSE

if(doMakePackage){

  doCheckPackage <- FALSE
  # generate the package
  Rcpp.package.skeleton(
     name       = "ZAp",
     path       = "C:/UsrLocal/temp",
     force      = TRUE,
     maintainer = "Michael J. Meyer",
     email      = "spyqqqdia@yahoo.com",
     code_files = list.files("R",pattern=".*\\.R",full.names=TRUE),
     cpp_files  = list.files("src",pattern=".*\\.[cpp,hpp]",full.names=TRUE)
  )
  msg <- "\n\nNow manually edit src/RcppExports.cpp:\n"
  msg <- paste(msg,"\t(a) Put in the missing includes.\n")
  msg <- paste(msg,"\t(b) Eliminate duplicate function definitions.\n")
  cat(msg)
}

if(doCheckPackage){
  # check the package
  system("R CMD check ../ZA")
}