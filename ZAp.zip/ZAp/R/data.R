cat("Reading data.R\n")
source("R/globals.R")
source("R/DataUtils.R")



# setwd("C:/Users/MeyerM/Projects/R/Lprocess")
# source("R/data.R")

# Currently we are simulating the swap market only.
# Thus starting Libor curve and covariance (correlation) matrix contain
# swap Libors only.
# Starting curves in data have annualized Libors as needed in the path
# simulation (recall that the volas and correlations are for annualized Libors
# also).
#


if(doReadMarketParams){

    cat("Reading SWAP startCurve.\n")
    swapStartCurve <- as.vector(scan("data/swapStartCurve.csv"))
    numSwapLibors <- length(swapStartCurve)
    swapShiftValue <- -0.01931167
    swapShiftVector <- rep(swapShiftValue,numSwapLibors)
    
    cat("Reading SWAP volas.\n")
    swapVols <- as.vector(scan("data/swapVols.csv"))
    if(!(length(swapVols) == numSwapLibors)){

       msg <- "\nNumbers of Swap Libors and Volas not equal:\n"
       msg <- paste(msg,"length(swapVols):",length(swapVols),"\n")
       msg <- paste(msg,"length(swapCurve):",numSwapLibors,"\n")
       stop(msg)
    }
    cat("Reading SWAP correlation matrix.\n")
    swapCorr <- as.matrix(read.csv("data/swapCorr.csv",sep=";", header=FALSE))
    colnames(swapCorr) <- NULL
    rownames(swapCorr) <- NULL
    if(!(nrow(swapCorr) == numSwapLibors) ||
       !(nrow(swapCorr) == numSwapLibors)){
       
       msg <- "\nSwap correlation matrix incompatibel with length of swap curve:\n"
       msg <- paste(msg,"dim(swapCorr):",dim(swapCorr),"\n")
       msg <- paste(msg,"length(swapCurve):",numSwapLibors,"\n")
       stop(msg)
    }
}
