source("src/Env.R")
library(Rcpp)

# R-console input:
#   setwd("C:/Users/MeyerM/Projects/R/Lprocess")
#   source("R/compileCpp.R")

# put Rtools into the PATH

# add Rtools to the path and reset the path to the R-packages
# for the Rcpp includes.
fixEnv()


  doCompilePaths      <- FALSE
  doCompileMatrix     <- TRUE
  doCompileUtils      <- FALSE
  doCompileSwap       <- TRUE
  doCompileTests      <- FALSE


# must be compiled before paths.cpp
if(doCompileMatrix){
  cat("\nCompiling matrix.cpp:")
  newFunctions <- sourceCpp("src/matrix.cpp")
  cat("\nExporting:")
  print(newFunctions)
}
if(doCompilePaths){
  cat("\nCompiling paths.cpp:")
  newFunctions <- sourceCpp("src/paths.cpp")
  cat("\nExporting:")
  print(newFunctions)
}
if(doCompileUtils){
  cat("\nCompiling utils.cpp:")
  newFunctions <- sourceCpp("src/utils.cpp")
  cat("\nExporting:")
  print(newFunctions)
}
if(doCompileSwap){
  cat("\nCompiling swap.cpp:")
  newFunctions <- sourceCpp("src/swap.cpp")
  cat("\nExporting:")
  print(newFunctions)
}
if(doCompileTests){
  cat("\nCompiling cppTests.cpp:")
  newFunctions <- sourceCpp("src/cppTests.cpp")
  cat("\nExporting:")
  print(newFunctions)
}
