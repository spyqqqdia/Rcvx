cat("Reading globals.R\n")
source("R/Env.R")

Sys.setenv(LANG = "en")
Sys.setlocale("LC_ALL", "English")
# Put Rtools and the C++ compiler on the PATH etc.
fixEnv()


# now handled in Env.R::fixEnv()
if(FALSE){
  # add RTools to the PATH variable if it is not in it already
  the_PATH <- Sys.getenv("PATH")
  bin_RTools <- "C:/Rtools/bin"
  bin_MinGW <- "C:/Rtools/mingw_$(WIN)/bin/"

  if(!(bin_RTools %in% strsplit(the_PATH,";")[[1]]))
     Sys.setenv(PATH = paste("C:/Rtools/bin", the_PATH, sep=";"))
  Sys.setenv(BINPREF = "C:/Rtools/mingw_$(WIN)/bin/")
}




doReadMarketParams <- TRUE

