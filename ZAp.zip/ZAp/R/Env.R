cat("Reading Env.R\n")


# Read:
# https://stevemosher.wordpress.com/step-six-fixing-your-path/


# source("src/Env.R")

setPath <- function(){

    # path to RTools and R
    path <- "C:/Rtools/bin;C:/Rtools/mingw_64/bin;C:/Rtools/mingw_32/bin;"
    path <- paste(path,"C:/Program Files/R/R-3.5.0/bin/x64;",sep="")
    # path to other needed things
    path <- paste(path,"C:/Perl64/site/bin;C:/Perl64/bin;",sep="")
    path <- paste(path,"C:/ProgramData/Oracle/Java/javapath;",sep="")
    path <- paste(path,"C:/Windows/system32;C:/Windows;",sep="")
    path <- paste(path,"C:/TEXLIVE/2016/bin/win32;C:/TEXLIVE/2016/bin/win32;",sep="")
    path <- paste(path,"C:/Java/jdk1.7.0_55__64bit/bin;",sep="")
    path <- paste(path,"C:/Program Files/Java/jdk1.7.0_65/bin;",sep="")
    Sys.setenv(PATH=path)
}


# .libPaths() shows the path to the directory where the packages are installed.
# We need to fix the environment variables pointing to this directory so that
# sourceCpp finds the include files in the Rcpp package
#
fixEnv <- function(){

    setPath()
    r_libs_user <- "C:/UsrLocal/R/R_libs/3.5"
    home <- "C:/UsrLocal/R"
    Sys.setenv(R_LIBS_USER=r_libs_user)
    Sys.setenv(HOME=home)
    Sys.setenv(R_USER=home)
    Sys.setenv(HOMEPATH=home)
    Sys.setenv(BINPREF = "C:/Rtools/mingw_$(WIN)/bin/")
    # this is what sourceCpp uses for the Rcpp includes
    .libPaths(r_libs_user)
}