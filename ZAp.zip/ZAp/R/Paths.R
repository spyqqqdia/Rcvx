cat("Reading Paths.R\n")


# Range [first,last] of indices of the Libors of market marketID in the
# forward curves of the full multimarket.
#
indexRange <- function(marketID){

    if(marketID == "BUND") range_BUND_EUR else
    if(marketID == "SWAP") range_SWAP_EUR else
    if(marketID == "REAL") range_BUND_REAL else
    if(marketID == "CPI") idx_CPI else {
    
       cat("\nUnknown marketID: ",marketID,", aborting.\n")
       stop()
    }
}

