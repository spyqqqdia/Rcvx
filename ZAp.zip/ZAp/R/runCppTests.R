source("R/globals.R")
source("R/cppTests.R")



# setwd("C:/UsrLocal/temp/ZAp")
# source("R/runCppTests.R")




doPassByValueTest <- FALSE
doAddConstToNumVecTest <- TRUE



if(doPassByValueTest) testPassByValue()
if(doAddConstToNumVecTest) testNumVecAddConst()
