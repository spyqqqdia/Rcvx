cat("Reading plots.R\n")

plotPaths <- function(){

    go_on <- TRUE
    while(go_on){
    

        tries <- 0
        curveId <- "X"
        while(tries<3 && !(curveId %in% c("B","S","R"))){
        
            cat("Enter curve ('B':BUND, 'S':SWAP, 'R':REAL; curve: ")
            curveId <- scan(what= character())
            if(curveId %in% c("B","S","R")) tries <- 3 else {
            
               tries <- tries+1
               cat(paste("Illegal entry: ",curveId, ", try again, enter curve:",sep=""))
            }
        }
        if(!(curveId %in% c("B","S","R"))){

            cat("\nNo reasonable entry, will plot BUND curve.\n")
            curveId <- "B"
        }
        curveRange <- if(curveId=="B") range_BUND_EUR else
                      if(curveId=="S") range_SWAP_EUR else range_BUND_REAL
                      
        plotTitle <- if(curveId=="B") "BUND Curve" else
                     if(curveId=="S") "SWAP_Curve" else "BUND_REAL Curve"

        cat("Enter number of path:")
        pathNum <- scan()
        path <- pathList[[pathNum]]      # matrix with forward curves in rows
        # forward curves after 0,1,2,3 years:
        fwdCurves <- t(path[c(1,12,24,36),curveRange])
        idx <- matrix(rep(1:length(fwdCurves[,1]),4),ncol=4,byrow=FALSE)
        colrs <- c("green","blue","red","black")
        matplot(idx,fwdCurves,
           main=plotTitle, xlab="LiborIdx", ylab="Libor",col=colrs,type="l"
        )
        tags <- c("L(0)","L(1Y)","L(2Y)","L(3Y)")
        legend("topleft",tags,fill=colrs)
    
        cat("Another one (0/1)? go_on:")
        if(scan()==0) go_on=FALSE
    }
}



# Does the same as plotPaths butr reads the paths from the csv files we have
# written them to. This is to check if the paths which IDL reads are OK.
#
plotPaths_1 <- function(){

    root <- "results/paths/paths_csv/"
    go_on <- TRUE
    while(go_on){


        tries <- 0
        curveId <- "X"
        while(tries<3 && !(curveId %in% c("B","S","R"))){

            cat("Enter curve ('B':BUND, 'S':SWAP, 'R':REAL; curve: ")
            curveId <- scan(what= character())
            if(curveId %in% c("B","S","R")) tries <- 3 else {

               tries <- tries+1
               cat(paste("Illegal entry: ",curveId, ", try again, enter curve:",sep=""))
            }
        }
        if(!(curveId %in% c("B","S","R"))){

            cat("\nNo reasonable entry, will plot BUND curve.\n")
            curveId <- "B"
        }
        plotTitle <- if(curveId=="B") "BUND Curve" else
                     if(curveId=="S") "SWAP_Curve" else "BUND_REAL Curve"

        cat("Enter number of path:")
        pathNum <- scan()
        
        infix <- if(curveId=="B") "BUND" else
                 if(curveId=="S") "SWAP" else "REAL"
                      
        pathFile <- paste(root,infix,"/path_",pathNum,".txt",sep="")
        
        path <- as.matrix(read.csv(pathFile,header=FALSE))     # matrix with forward curves in rows
        # forward curves after 0,1,2,3 years:
        fwdCurves <- t(path[c(1,12,24,36),])
        idx <- matrix(rep(1:length(fwdCurves[,1]),4),ncol=4,byrow=FALSE)
        colrs <- c("green","blue","red","black")
        matplot(idx,fwdCurves,
           main=plotTitle, xlab="LiborIdx", ylab="Libor",col=colrs,type="l"
        )
        tags <- c("L(0)","L(1Y)","L(2Y)","L(3Y)")
        legend("topleft",tags,fill=colrs)

        cat("Another one (0/1)? go_on:")
        if(scan()==0) go_on=FALSE
    }
}