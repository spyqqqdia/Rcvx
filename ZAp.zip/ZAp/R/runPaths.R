source("R/data.R")   # globals.R, StatUtils.R, sql.R, SynData.R,
#                         Paths.R, TestPaths.R
source("R/Env.R")
source("R/plots.R")



# setwd("C:/UsrLocal/temp/ZAp")
# source("R/runPaths.R")

doPlotPaths <- FALSE
doComputePaths <- FALSE   # compute paths and assign to global variable pathList
doWritePaths <- TRUE      # write paths in pathList.rds to text files






if(doPlotPaths){

   plotPaths_1()

}



if(doComputePaths){

    nPaths <- 420
    nSteps <- 150
    nPCs <- 5
    deltaT <- 1/12
    pathList <- listOfPaths(nPaths,nSteps,nPCs,deltaT)
}

# Write paths from variable pathList to text files formatted for input to IDL
# (forward curves in columns).
#
if(doWritePaths){

    writePaths(pathList)
}


