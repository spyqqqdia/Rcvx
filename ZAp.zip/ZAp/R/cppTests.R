# Testing the most basic functionality of Rcpp to resolve
# unexplained phenomena in cpp code.
#


# Here we test if pass by value parameters really remain unchanged.
#
testPassByValue <- function(){

   x <- c(0.0,0.0)
   passByValueTest(x)
}


# Here we test if addition of a constant applies to _all_ coordinates of a
# numeric vector
#
testNumVecAddConst <- function(){

   a <- c(0,0,0,0,0)
   shift <- 1.0
   testConstToNumVec(shift,a)
}