cat("Reading DataUtils.R\n")



#------------------- utils for extracting data from csv -----------------------#


# @param d vector of length n
# @param A nxn matrix
# @return matrix product diag(d)*A*diag(d) = (A_{ij}d_id_j)
#
dd_mult <- function(A,d){

   n <- nrow(A)
   stopifnot(length(d)==n && length(d)==ncol(A))
   d_in_rows <- matrix(rep(d,n),nrow=n,byrow=TRUE)
   d_in_cols <- matrix(rep(d,n),nrow=n,byrow=FALSE)
   A*d_in_rows*d_in_cols
}

# This function has astronomical memory consumption (like 20000 GB)
# Why??
#
# @param d vector of length n
# @param A nxn matrix
# @return matrix product diag(d)*A*diag(d) = (A_{ij}d_id_j)
#
dd_mult_0 <- function(A,d){

    stopifnot(length(d)==ncol(A) && length(d)==nrow(A))
    outer(1:nrow(A), 1:ncol(A), FUN = function(i,j) A[i,j]*d[i]*d[j])
}


# Computes the eigendecomposition of covMat and returns a
# list with the following components
#   .covMat:  the covariance matrix
#   .eigVecs: the matrix of eigenvectors
#   .eigVals: the vector of eigenvalues
#   .scaledPCs: the matrix where col_j = sqrt(eigval_j)*eigVec_j
#
spectralDecomposition <- function(covMat){

    eigCovMat <- eigen(covMat,symmetric=TRUE)
    eigVecs <- eigCovMat$vectors
    eigVals <- eigCovMat$values
    # eigen computes slightly negative eigenvalues for some nonnegative definite
    # covMat, rectify by setting these equal to zero
    eigVals[eigVals<0] <- 0
    scaledPCs <- eigVecs %*% diag(sqrt(eigVals))
    list(
        .covMat = covMat,
        .eigVecs = eigVecs,
        .eigVals = eigVals,
        .scaledPCs = scaledPCs
    )
}




# The entire covariance matrix (annualized libors, stepsize = 1Y)
#
getCovMat <- function(corrMat,sigmas)
   mm_bimult_diag(corrMat,sigmas,sigmas)     # RCpp export function




