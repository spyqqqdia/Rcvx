library(R.utils)


# setwd("C:/UsrLocal/temp/ZAp")
# source("R/runCppTests.R")

# Already installed:
#     devtools
#     covr
#
#

pkgs <- c("covr")

CRANextras = "http://nexus-more.dfa.local/repository/r-proxy-cran/"
useRepos(repos=CRANextras)
# install.packages(pkgs, repos = CRANextras)


library(devtools)
library(covr)

loadedPackages <- (.packages())

cat("\n\nPackages currently loaded:\n",loadedPackages,"\n\n")