#include <Rcpp.h>
#include <cmath>
using namespace Rcpp;

/**
 * WARNING: this will modify x outside the function
 * even though we use pass by value!!
 * Apparently the R-function sourceCpp does something to
 * the source code.
 */
NumericVector modX0(NumericVector x){

    x[0]=1;
    return x;
}

// testing if pass by value parameters are _really_ passed by value
// Fact: they are NOT, so sourceCpp does something to our Cpp source code.

// [[Rcpp::export]]
void passByValueTest(NumericVector x){

    NumericVector u = modX0(x);

    Rcout << std::endl << "\nvector u:\n";
    for(int i=0;i<u.size();i++) Rcout << u[i] << ",  ";

    Rcout << std::endl << "\nvector x:\n";
    for(int i=0;i<x.size();i++) Rcout << x[i] << ",  ";
}

// testing if NumericVectors are multiplied as expected

// [[Rcpp::export]]
void testMultNumVec(double q, NumericVector a, NumericVector b){

    NumericVector x = q*a*b;
    Rcout << std::endl << "\nVector q*a*b:\n";
    for(int i=0;i<x.size();i++) Rcout << x[i] << ",  ";
}


// testing if NumericVectors are multiplied as expected

// [[Rcpp::export]]
void testAddConstToNumVec(double shift, NumericVector a){

    NumericVector x = a+shift;
    Rcout << std::endl << "\nVector a:\n";
    for(int i=0;i<x.size();i++) Rcout << a[i] << ",  ";
    Rcout << std::endl << "\nVector a+" << shift << ":\n";
    for(int i=0;i<x.size();i++) Rcout << x[i] << ",  ";
}



// testing if repeated calls to the random nuber generators
// really do generate independent deviates

// [[Rcpp::export]]
void testRNG(int reps){

    Rcout << "\n\n\nRepeated uniform deviates:\n";
    for(int i=0;i<reps;i++){
    
      NumericVector u = runif(5);
      Rcout << "\nSet " << i << ":\n";
      for(int i=0;i<u.size();i++) Rcout << u[i] << " ";
    }
    Rcout << "\n\n\nRepeated normal deviates:\n";
    for(int i=0;i<reps;i++){

      NumericVector u = rnorm(5);
      Rcout << "\nSet " << i << ":\n";
      for(int i=0;i<u.size();i++) Rcout << u[i] << " ";
    }
}