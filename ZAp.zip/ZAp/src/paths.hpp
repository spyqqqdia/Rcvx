#ifndef sxy__paths_h
#define sxy__paths_h



#include <Rcpp.h>
#include <cmath>
#include "matrix.hpp"

using Rcpp::NumericVector;
using Rcpp::NumericMatrix;


// This file defines the C++ kernels for path computation of the Libor market
// model in the forward martingale measure at the simulation horizon.





//============================ Lognormal Paths ===============================//


/** Computes one lognormal path of a discrete forward curve under the forward
 * martingale measure at the simulation horizon.
 * The maturity grid of the forward curve is assumed to be regular of with
 * a mesh width equal to the length dt of the time steps of the simulation.
 *
 * Our volas and PCs are for annualized Libors, so here we get paths of
 * forward curves with annualized Libors also!
 * Moreover the volas are scaled to time steps of one year as usual so we need
 * to multiply with sqrt(dt) in each time step.
 *
 * @param L0 unshited starting Libor curve, absolute rates.
 * @param shift shift value to be applied to every libor
 *
 * @param scaled_pc matrix of principal components of the
 * covariance matrix scaled with the eigenvalues (for simulation):
 *     col_j(lambda_pc) = sqrt(lambda_j)* pc_j,
 * where pc_j denotes the j-th principal component of the covariance matrix
 * of the Libor increments and lambda_j the corresponding eigenvalue of the
 * covariance matrix.
 *
 * @param sigma vector of log-Libor vols.
 * @param dt size of time step in days.
 * @param bundBegin: first (zero based) index of BUND libors in the full
 * Libor curve of the multimarket
 * @param bundEnd: one past the last (zero based) index of BUND libors in the
 * full Libor curve of the multimarket
 *
 * @return matrix of libor curves along the time steps of the path,
 * row_j contains the libor curve after time step j, row_0 is the starting
 * curve.
 */
// [[Rcpp::export]]
NumericMatrix
nextGeometricRiskNeutralPath(
        NumericVector L0,
        int nSteps,
        NumericVector shift,
        NumericVector sigma,
        NumericMatrix rho,
        NumericMatrix scaled_pc,
        int dt,
        int bundBegin,
        int bundEnd,
        int swapBegin,
        int swapEnd,
        int realBegin,
        int realEnd
);

/**
 *  @param kappa: vector of kappas (one kappa for each Libor).
 *
 */
// [[Rcpp::export]]
NumericMatrix
nextHybridPath(
        NumericVector kappa,
        NumericVector L0,
        int nSteps,
        NumericVector shift,
        NumericVector sigma,
        NumericMatrix rho,
        NumericMatrix scaled_pc,
        int dt,
        int bundBegin,
        int bundEnd,
        int swapBegin,
        int swapEnd,
        int realBegin,
        int realEnd
);


# endif