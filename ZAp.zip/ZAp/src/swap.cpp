#include "utils.hpp"
#include "swap.hpp"

using namespace Rcpp;





//-------------------------------- Class Swap --------------------------------//



/** Constructor for swaps when fixrate is already known
     *  (e.g. when the swap has been allocated in the past, before refDate)
     *
     * @param nPeriods: number of 180 day accrual periods
     */
Swap::Swap(
   double the_nominal, int the_startDate, int the_nPeriods, double the_fixRate
):
   nominal(the_nominal),
   startDate(the_startDate),
   nPeriods(the_nPeriods),
   fixRate(the_fixRate)
{
   if((startDate < 0) | (nPeriods % 2 == 1)){
   
       Rcerr << "Swap::constructor, startDate < 0 or numPeriods not even:\n"
             << "startDate = " << startDate << ", numPeriods = " <<  nPeriods
             << "\n\n";
       stop("Aborting.");
   }
}




// nPeriods: number of 180 day accrual periods
// _startDate: offset from refDate = startDate(simulation)
//
double
Swap::fixedRate(int dt, const NumericMatrix& forwardPath){

   int nSteps = forwardPath.ncol()-1;
   if(startDate/dt >= nSteps){
   
      Rcerr << "Swap::fixedRate, forward path not long enough:\n"
          << "startDate/dt = " << startDate/dt << " >= nSteps = "
          <<  nSteps << "\n\n";
      stop("Aborting.");
   }
   NumericVector forwardCurve;
   // find the curves in the forwardPath which interpolate the
   // forward curve at start date:
   int i = startDate/dt;   // index of left interpolating curve

   if(startDate==i*dt){  // path has curve on startDate

      // map curve on path to 180 day grid, note: dt = dTau in simulation
      forwardCurve = mappedForwardCurve(nPeriods,forwardPath( _,i),dt);

   }  else {  // path does not have curve on startDate, interpolate

      assert(i+1<=nSteps);
      NumericVector curveLeft = forwardPath( _,i);
      int daysLeft = startDate % dt;
      NumericVector curveRight = forwardPath( _,i+1);
      int daysRight = dt-daysLeft;
      
      // automatically maps to 180 day maturity grid
      forwardCurve = interpolatedForwardCurve(
         nPeriods, curveLeft, daysLeft, curveRight, daysRight, dt
      );
   }
   return swapRate(forwardCurve);
}









