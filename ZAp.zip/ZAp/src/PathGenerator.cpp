#include "PathGenerator.hpp"

using namespace Rcpp;


/** Returns a PathGenerator of specified type with 30 day time steps
 *  until the first time point past the end of numQuarter quarters.
 *
 * @param pathType: "geometricRiskNeutral", "hybrid".
 *
 */
PathGenerator*  makePathGenerator(
   string pathType,
   int nPath, int numQuarters,
   NumericVector kappa,
   NumericVector L0,
   NumericVector shift,
   NumericVector sigma,
   NumericMatrix rho,
   NumericMatrix scaled_pc,
   int bundBegin, int bundEnd,
   int swapBegin, int swapEnd,
   int realBegin, int realEnd
){
   int dt = 30;  // time step size in days
   int nSteps = 1 + 3*numQuarters;

   if(pathType=="geometricRiskNeutral"){

      return new GeometricRiskNeutralPathGenerator(
         L0,nSteps,shift,sigma,rho,scaled_pc,dt,
         bundBegin,bundEnd,swapBegin,swapEnd,realBegin,realEnd
      );
   } else if(pathType=="hybrid"){

      return new HybridModelPathGenerator(
           kappa,L0,nSteps,shift,sigma,rho,scaled_pc,dt,
           bundBegin,bundEnd,swapBegin,swapEnd,realBegin,realEnd
      );
   } else {

      Rcerr << "\n\nUnknown pathType: " << pathType << "\nMust be one of: "
            << "geometricRiskNeutral, hybrid. Aborting.";
      stop("Aborted.");
   }
   return 0;       // nullptr
}


