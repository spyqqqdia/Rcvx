#ifndef xrcv_swap_h
#define xrcv_swap_h

#include <Rcpp.h>
#include "utils.hpp"
using Rcpp::NumericMatrix;




/**------------------------------ Class Swap --------------------------------**/



/** Swaps with years = 360 days, paying float every 180 days, fixed every
 *  360 days.
 *
 *  refDate is the startDate of the forward curve simulation but is not
 *  specified since all
 */
class Swap {

    double nominal;
    int startDate;        // days relative to refDate
    int nPeriods;         // number of 180 day accrual periods
    double fixRate;       // annualized rate paid on fixed leg

    public:

    /** Constructor for swaps when fixrate is already known
     *  (e.g. when the swap has been allocated in the past, before refDate)
     *
     * @param nPeriods: number of 180 day accrual periods
     */
    Swap(
       double the_nominal, int the_startDate, int the_nPeriods,
       double the_fixRate = NA_REAL
    );

    int getStartDate(){ return startDate; }
    int getNumPeriods(){ return nPeriods; }
    double getNominal(){ return nominal; }
    double getFixedRate(){ return fixRate; }
    /**
     * @param r: annualized rate
     */
    void setFixedRate(double r){ fixRate=r; }

    
    /** Fixed rate when swap is allocated in given forward path.
     * @param dt size of time step of forwardPath in days.
     */
    double fixedRate(int dt, const NumericMatrix& forwardPath);

};





#endif