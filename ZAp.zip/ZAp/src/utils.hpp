#ifndef rcs25_utils_h
#define rcs25_utils_h

#include <Rcpp.h>
using Rcpp::NumericVector;
using Rcpp::NumericMatrix;


//------------------ Rates directly from a forward curve ---------------------//


/** forward rate (nonannualized) for accrual interval [d+startDate,d+endDate]
 *  where d = validityDate(forwardCurve)
 *  computed from forwardCurve and hence valid on the same date as this curve.
 *
 * @param dTau meshwidth of regular maturity time grid of forwardCurve
 */
// [[Rcpp::export]]
double
forwardRate(
   int startDate, int endDate, NumericVector forwardCurve,
   int dTau
);


/** libor6M (nonannualized) computed from forwardCurve and hence valid on
 *  the same date as this curve.
 *
 * @param dTau meshwidth of regular maturity time grid of forwardCurve
 */
 // [[Rcpp::export]]
double
libor6M(NumericVector forwardCurve, int dTau);




/** Present value of a basis point paying (1.0 EUR) every 360 days,
 *  along the entire length of the forwardCurve.
 *
 * @param forwardCurve: discrete forward curve with maturity
 * grid of 180 days.
 */
// [[Rcpp::export]]
double bvp(NumericVector forwardCurve);


/** Swaprate paid on fixed leg for a swap along the forward curve.
 *
 * The forward curve must be discrete with a maturity grid of 180 days
 * and be valid on the startDate of the swap. It must have exactly as many
 * periods as the swap.
 */
// [[Rcpp::export]]
double swapRate(NumericVector forwardCurve);



/** Maps originalCurve to a maturity grid of 180 days with nPeriods periods,
 *  same refDate.
 */
// [[Rcpp::export]]
NumericVector
mappedForwardCurve(
   int nPeriods, NumericVector originalCurve, int dTau
);




//------------------------- Rates by interpolation ---------------------------//


/** forward rate (nonannualized) for accrual interval [d+startDate,d+endDate]
 *  where d = validityDate(leftCurve) and valid on date t where
 *
 *     t = validityDate(leftCurve) + daysLeft
 *       = validityDate(rightCurve) - daysRight
 *
 *  computed by interpolation from leftCurve, rightCurve.
 *
 * @param dTau meshwidth (in days) of regular maturity time grid of
 * interpolating curves, must be <= 180.
 */
// [[Rcpp::export]]
double
interpolatedForwardRate(
   int startDate, int endDate,
   NumericVector leftCurve, int daysLeft,
   NumericVector rightCurve, int daysRight,
   int dTau
);



/** libor6M (nonannualized) for accrual interval [d+startDate,d+endDate]
 *  where d = validityDate(leftCurve) and valid on date t where
 *
 *     t = validityDate(leftCurve) + daysLeft
 *       = validityDate(rightCurve) - daysRight
 *
 *  computed by interpolation from leftCurve, rightCurve.
 *
 * @param dTau meshwidth (in days) of regular maturity time grid of
 * interpolating curves, must be <= 180.
 */
 // [[Rcpp::export]]
double
interpolatedLibor6M(
   NumericVector leftCurve, int daysLeft,
   NumericVector rightCurve, int daysRight,
   int dTau
);


/** libor6M (nonannualized) at date t in forward path forwardPath
 *
 * @param t: date (offset from refDate = startDate of forward path simulation)
 * @param dt step size of forward path in days =
             meshwidth of regular maturity time grid of forwardCurves
 */
// [[Rcpp::export]]
double
libor6M_at_date(int t, int dt, NumericMatrix forwardPath);




/** Discrete forward curve F with regular 180 day maturity grid
 *  of nPeriods periods interpolated from
 *  (a) a discrete forward curve curveLeft valid daysLeft before the
 *      the validity date of F, and
 *  (b) a discrete forward curve curveRight valid daysRight after the
 *      validity date of F,
 *  where both forward curves curveLeft and curveRight have a
 *  regular maturity grid of dTau days.
 *
 *  It is assued that the interpolating curves are long enough to cover all
 *  periods of the interpolated curve.
 *  Also assumed:
 *
 *          validityDate(rightCurve) = validityDate(leftCurve) + dTau
 *
 *  (as usual if the interpolating curves are forward curves at consecutive
 *   steps in a simulation of discrete Libor curves).
 *
 *  The Libors are _not_ annualized.
 */
 // [[Rcpp::export]]
NumericVector
interpolatedForwardCurve(
   int nPeriods,
   NumericVector curveLeft, int daysLeft,
   NumericVector curveRight, int daysRight,
   int dTau
);








#endif
