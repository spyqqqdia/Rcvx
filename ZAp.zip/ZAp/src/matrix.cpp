#include <Rcpp.h>
#include <cmath>
#include <iomanip>

using namespace Rcpp;
//using Rcpp::sugar::rep;
using std::endl;



//---------------------------- Matrix Operations -----------------------------//

// Trying to allocate an empty matrix
//
// [[Rcpp::export]]
NumericMatrix emptyMatrix(){

    NumericMatrix A;
    return(A);
}



// we have to implement transpose, matrix-vector and
// matrix-matrix multiplication ourselves:
// A^T
// [[Rcpp::export]]
NumericMatrix diagMatrix(const NumericVector& d){

   NumericMatrix R(d.size(),d.size());
   for(int i=0; i<R.nrow(); ++i) R(i,i)=d[i];
   return R;
}

// we have to implement transpose, matrix-vector and
// matrix-matrix multiplication ourselves:
// A^T
// [[Rcpp::export]]
NumericMatrix transpose(const NumericMatrix& A){

   NumericMatrix R(A.ncol(),A.nrow());
   for(int i=0; i<R.nrow(); ++i)
      for(int j=0; j<R.ncol(); ++j) R(i,j)=A(j,i);

   return R;
}
// Ax
// [[Rcpp::export]]
NumericVector mv_mult(const NumericMatrix& A, const NumericVector& x){

   if(x.size()!=A.ncol()){
      Rcerr << "\nCpp-mmult, Ax: incompatible dimensions: ncol(A): "
            << A.ncol() << ", size(x): " << x.size();
      stop("Aborting.\n");
   }
   NumericVector r(A.nrow());
   for(int i=0; i<A.nrow(); ++i)
      for(int j=0; j<x.size(); ++j) r(i)+=A(i,j)*x[j];
      
   return r;
}
// AB
// [[Rcpp::export]]
NumericMatrix mm_mult(const NumericMatrix& A, const NumericMatrix& B){

   if(A.ncol()!=B.nrow()){
      Rcerr << "\nCpp-mmult, AB: incompatible dimensions: ncol(A): "
            << A.ncol() << ", nrow(B): " << B.nrow();
      stop("Aborting.\n");
   }

   NumericMatrix R(A.nrow(),B.ncol());
   for(int i=0; i<A.nrow(); ++i)
      for(int j=0; j<B.ncol(); ++j)
         for(int k=0; k<A.ncol(); ++k) R(i,j)+=A(i,k)*B(k,j);

   return R;
}
// A*diag(d)
// [[Rcpp::export]]
NumericMatrix mm_rightmult_diag(const NumericMatrix& A, const NumericVector& d){

   if(d.size()!=A.ncol()){
      Rcerr << "\nCpp-mm_rightmult_diag, A*diag(d): incompatible dimensions; "
            << " ncol(A): " << A.ncol() << ", size(d): " << d.size();
      stop("Aborting.\n");
   }
   NumericMatrix R(A);
   for(int j=0; j<R.ncol(); ++j)
      for(int i=0; i<R.nrow(); ++i) R(i,j)*=d[j];

   return R;
}
// diag(d)*A*diag(e)
// [[Rcpp::export]]
NumericMatrix mm_bimult_diag(
   const NumericMatrix& A, const NumericVector& d, const NumericVector& e
){
   if(d.size()!=A.nrow() || e.size()!=A.ncol()){
      Rcerr << "\nCpp-mm_bimult_diag, diag(d)*A*diag(e): incompatible dimensions; "
            << " nrow(A): " << A.ncol() << ", size(d): " << d.size()
            << " ncol(A): " << A.ncol() << ", size(e): " << e.size();
      stop("Aborting.\n");
   }
   NumericMatrix R(A);
   for(int i=0; i<R.nrow(); ++i)
      for(int j=0; j<R.ncol(); ++j) R(i,j)*=d[i]*e[j];

   return R;
}


//------------------------------- Printing -----------------------------------//

// [[Rcpp::export]]
void
printVector(const NumericVector& vec,int precision){

    int numbersPerLine = int(10*(6.0/precision));
    Rcout << std::setprecision(precision);
    for(int i=0;i<vec.size()-1;i++){
       Rcout << vec[i] << ",  ";
       if((i>0)&&(i%numbersPerLine==0)) Rcout << std::endl;
    }
    Rcout << vec[vec.size()-1];
}

// [[Rcpp::export]]
void
printMatrix(NumericMatrix& A,int precision){

    for(int i=0;i<A.nrow();++i){

       printVector(A(i,_),precision);
       Rcout << std::endl;
    }
}




//--------------------------------- Tests ------------------------------------//


//  Testing matrix allocation, setting rows and columns and indexation.
//
// [[Rcpp::export]]
void
testMatrixIndexation(){

    NumericMatrix A(3,4);
    NumericVector r(4);
    for(int i=0;i<4;i++) r[i]=i;
    A(0,_) = r;                             // row 0
    NumericVector c(3);
    for(int i=0;i<3;i++) c[i]=2+i;
    A(_,0) = c;                             // col 0, now A(0,0)=2!

    Rcout << "\nTesting matrix indexation:\n";
    Rcout << "\nIndexation style A(i,j):\n";
    Rcout << "Row(0) of A (should be 2123): ";
    for(int j=0;j<4;j++) Rcout << A(0,j);
    Rcout << endl << "Column(0) of A (should be 234): ";
    for(int i=0;i<3;i++) Rcout << A(i,0);
    Rcout << "\n\nMatrix indices are zero based, A(i,j) is the correct form.";
}

// [[Rcpp::export]]
void
testMatrixMultiplication(){

    NumericMatrix A(3,3);
    A(0,0)=A(1,1)=A(2,2)=1.0;
    A(2,0)=1.0;
    
    NumericMatrix B(3,3);
    B(0,0)=B(1,1)=B(2,2)=1.0;
    B(0,2)=2.0;

    NumericVector x(3);
    x(0)=1.0; x(1)=2.0; x(2)=3.0;

    Rcout << "\nTesting matrix transpose and multiplication:\n";
    Rcout << "\nMatrix A:\n";
    printMatrix(A,0);
    Rcout << "\nTranspose:\n";
    NumericMatrix At=transpose(A);
    printMatrix(At,0) ;
    
    Rcout << "\nMatrix-Vector multiplication:\n";
    Rcout << "Vector x:\n";
    printVector(x,0);
    Rcout << "\nAx:\n";
    printVector(mv_mult(A,x),0);
    
    Rcout << "\nMatrix-Matrix multiplication:\n";
    Rcout << "\nMatrix B:\n";
    printMatrix(B,0);
    Rcout << "\nAB:\n";
    NumericMatrix R(mm_mult(A,B));
    printMatrix(R,0);
    Rcout << "\nBA:\n";
    NumericMatrix S(mm_mult(B,A));
    printMatrix(S,0);
}