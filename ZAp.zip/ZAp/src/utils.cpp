#include "utils.hpp"
using namespace Rcpp;



//------------------ Rates directly from a forward curve ---------------------//



// Recall: by assumption dTau <= 180 days = 6M.
// [[Rcpp::export]]
double forwardRate(
   int startDate, int endDate, NumericVector forwardCurve, int dTau
){

   int lC = forwardCurve.size()*dTau;    // length of curve in days
   if(endDate >= lC){
   
       Rcerr << "\n\nforwardRate, forwardCurve not long enough:\n"
           << " endDate = " << endDate << " >  length(forwardCurve) = " << lC
           << "\n\n";
       stop("Aborting.");
   }
   // first Libor(i) of forwardCurve intersecting I = [startDate, endDate],
   // max i:  i*dTau < startDate
   int i0 = startDate/dTau;
   // fraction of a accrual interval [i*dTau,(i+1)*dTau] in intersection
   double frac =  double((i0+1)*dTau-startDate)/dTau;
   // result rate
   double L = frac*forwardCurve[i0];    // first part

   int i=i0+1;
   // accrual interval [i*dTau,(i+1)*dTau] is fully contained in I
   while((i+1)*dTau <= endDate){ L += forwardCurve[i]; i++; }
   // now (i+1)*dTau > endDate

   // if [i*dTau,(i+1)*dTau] intersects I, i.e.:
   if(i*dTau < endDate){

      // fraction of accrual interval [i*dTau,(i+1)*dTau] in intersection
      frac = double(endDate-i*dTau)/dTau;
      L += frac*forwardCurve[i];
   }
   return L;
}


// [[Rcpp::export]]
double
libor6M(NumericVector forwardCurve, int dTau){

   return forwardRate(0,180,forwardCurve,dTau);
}



// Recall: forwardCurve has refDate = startDate and
// maturity grid = 180 days = half of a fixed side accrual period.
// [[Rcpp::export]]
double
bvp(NumericVector forwardCurve){

   int nPeriods = forwardCurve.size();
   double result=0.0;
   double sumRates = 0.0;
   for(int i=0;i<nPeriods/2;i++){

       // year i of swap (i-th accrual period on fixed side)
       sumRates += forwardCurve[2*i]+forwardCurve[2*i+1];
       // discount factor to discount from end of year i
       double df = exp(-sumRates);
       result+=df;
   }
   return result;
}



// [[Rcpp::export]]
double
swapRate(NumericVector forwardCurve){

   double sumForwardRates = sum(forwardCurve);
   double pvFloatSide = 1.0 - exp(-sumForwardRates);
   return pvFloatSide/bvp(forwardCurve);
}



// Maps originalCurve to a maturity grid of 180 days with nPeriods periods,
// same refDate.
// recall dTau: maturity grid spacing of originalCurve
// [[Rcpp::export]]
NumericVector mappedForwardCurve(
   int nPeriods, NumericVector originalCurve, int dTau
){
  int n = originalCurve.size();
  // check if original curve is long enough
  if(n*dTau < nPeriods*180){
  
      Rcerr << "\n\nmappedForwardCurve: original curve not long enough:\n"
            << "lenght(originalCurve) = " << n*dTau
            << "lenght(mappedCurve) = " << nPeriods*180 << "(days).\n";
      stop("Aborting.");
  }
  assert(n*dTau >= nPeriods*180);
  NumericVector resultCurve(nPeriods);

  // Libor resultCurve[j] has accrual interval
  // I_j = refDate(resultCurve)+[j*180,(j+1)*180]
  //
  for(int j=0;j<nPeriods;j++){

     // start and end date of accrual interval I_j of Libor(j) of result curve,
     // offsets from refDate(leftCurve)
     int startDate = j*180;
     int endDate = startDate+180;
     resultCurve[j]=forwardRate(startDate,endDate,originalCurve,dTau);
  }
  return resultCurve;
}



//------------------------- Rates by interpolation ---------------------------//



// Note: by assumption
//
//       refDate(resultCurve) = refDate(leftCurve)+daysLeft,
//       refDate(resultCurve) = refDate(rightCurve)-daysRight     and
//       refDate(rightCurve) - refDate(leftCurve) = daysLeft+daysRight = dTau
//
// The maturity grids of all curves are viewed as absolute grids (rather than
// grids relative to the curve refDates). Then these assumptions together imply
// that the
//    maturity grid of right curve = maturity grid of left curve \ first point
//
// (recall the regular spacing of maturities with meshwidth dTau).
//
// With this the interpolation is linear between the left curve and the right
// curve where the right curve is extended at the front by one Libor with
// constant extension.
//
// [[Rcpp::export]]
double
interpolatedForwardRate(
   int startDate, int endDate,
   NumericVector leftCurve, int daysLeft,
   NumericVector rightCurve, int daysRight,
   int dTau
){

   if((daysLeft<0)|(daysRight<0)){
   
      Rcerr << "\ninterpolatedForwardRate: daysLeft or daysRight < 0:\n"
            << "daysLeft = " << daysLeft << "daysRight = " << daysRight << "\n";
      stop("Aborting.");
   }
   if(daysLeft==0) return forwardRate(startDate,endDate,leftCurve,dTau);
   if(daysRight==0) return forwardRate(startDate,endDate,rightCurve,dTau);

   // now daysLeft, daysRight > 0 and we do have to interpolate.

   // check if left curve is long enough
   int lC = leftCurve.size()*dTau;         // length in days
   if(lC < endDate){

       Rcerr << "\ninterpolatedForwardRate, left interpolating curve not long enough:\n"
           << " endDate = " << endDate << " >  length(leftCurve) = " << lC
           << "\n\n";
       stop("Aborting.");
   }

   int dt = daysLeft+daysRight;
   double wLeft = double(daysLeft)/dt; // weight of left curve in interpolation
   double wRight = 1-wLeft;

   // result rate has accrual interval [daysLeft,daysLeft+180],
   // i-th accrual interval on curveLeft is [i*dTau,(i+1)*dTau], where
   // all dates are represented as offsets from validityDate(leftCurve)

   // first Libor(i) of leftCurve intersecting I_j, max i:  i*dTau < startDate
   int i0 = startDate/dTau;
   double liborLeftCurve = leftCurve[i0];
   // fraction of a accrual interval [i*dTau,(i+1)*dTau] in intersection
   double frac =  double((i0+1)*dTau-startDate)/dTau;

   int k0 = i0-1;    // Libor index of the right curve
   if(i0==0) k0 = 0; // constant exension at the front by one Libor
   double liborRightCurve = rightCurve[k0];

   // result rate
   double L = frac*(wLeft*liborLeftCurve + wRight*liborRightCurve);
   int i=i0+1;
   // accrual interval [i*dTau,(i+1)*dTau] is fully contained in accrual
   // interval [daysLeft,daysLeft+180] of libor6M
   while((i+1)*dTau <= endDate){
      L += wLeft*leftCurve[i] + wRight*rightCurve[i-1]; i++;
   }

   // if [i*dTau,(i+1)*dTau] intersects I_j, i.e.:
   if(i*dTau < endDate){

      // fraction of accrual interval [i*dTau,(i+1)*dTau] in intersection
      frac = double(endDate-i*dTau)/dTau;
      L += frac*(wLeft*leftCurve[i] + wRight*rightCurve[i-1]);
   }
   return L;
}


// [[Rcpp::export]]
double
interpolatedLibor6M(
   NumericVector leftCurve, int daysLeft,
   NumericVector rightCurve, int daysRight,
   int dTau
){

   return interpolatedForwardRate(
      daysLeft,daysLeft+180,leftCurve,daysLeft,rightCurve,daysRight,dTau
   );
}



// [[Rcpp::export]]
NumericVector
interpolatedForwardCurve(
   int nPeriods,
   NumericVector curveLeft, int daysLeft,
   NumericVector curveRight, int daysRight,
   int dTau
){

   int lC = curveLeft.size()*dTau;  // length in days
   int endInterpolatedCurve = daysLeft+nPeriods*180;
   if(endInterpolatedCurve > lC){

       Rcerr << "\ninterpolatedForwardCurve, left interpolating curve not long enough:\n"
           << " endInterpolatedCurve = " << endInterpolatedCurve
           << " >  length(leftCurve) = " << lC
           << "\n\n";
       stop("Aborting.");
   }
  
   NumericVector resultCurve(nPeriods);

   for(int j=0;j<nPeriods;j++){

      // start and end date of accrual interval I_j of Libor(j) of result curve,
      // offsets from refDate(leftCurve)
      int startDate = daysLeft+j*180;
      int endDate = startDate+180;
      resultCurve[j]= interpolatedForwardRate(
         startDate,endDate,curveLeft,daysLeft,curveRight,daysRight,dTau
      );
   }
   return resultCurve;
}


// [[Rcpp::export]]
double
libor6M_at_date(int t, int dt, NumericMatrix forwardPath){

   int nSteps = forwardPath.ncol()-1;
   if(t >= nSteps*dt){

       Rcerr << "libor6M(t), forward path not long enough:\n"
           << "t = " << t << " >= nSteps = " <<  nSteps << "\n\n";
       stop("Aborting.");
   }
   int indexLeftCurve = t/dt;       // index of left interpolating curve for libor6M
   NumericVector leftCurve = forwardPath( _,indexLeftCurve);     // forward curves in columns
   NumericVector rightCurve = forwardPath( _,1+indexLeftCurve);
   int daysLeft = t % dt;
   int daysRight = dt-daysLeft;
   return interpolatedLibor6M(leftCurve,daysLeft,rightCurve,daysRight,dt);

}


































