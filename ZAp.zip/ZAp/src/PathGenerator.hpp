#ifndef sxyrrz__pathgenerator_h
#define sxyrrz__pathgenerator_h



#include <Rcpp.h>
#include <cmath>
#include <string>
#include "matrix.hpp"
#include "paths.hpp"

using Rcpp::NumericVector;
using Rcpp::NumericMatrix;
using std::string;

/** Generates paths for a multimarket containing at most BUND, SWAP and
 *  REAL curves.
 * If there is no BUND curve simply instantiate the path generator
 * with bundBegin = bundEnd ( = e.g. = 0). Similarly for the other curves.
 */
class PathGenerator {

protected:
        NumericVector L0;                   // start curve (annualized rates!)
        int nSteps;
        NumericVector shift;                // Libor shifts
        NumericVector sigma;                // Libor vols
        NumericMatrix rho;                  // Libor correlation matrix
        NumericMatrix scaled_pc;            // principal components used in simulation in columns
        int dt;                             // time step in days
        int bundBegin; int bundEnd;         // Libor index range BUND curve
        int swapBegin; int swapEnd;         // Libor index range SWAP curve
        int realBegin; int realEnd;         // Libor index range REAL curve
        

    PathGenerator(
        NumericVector the_L0,
        int the_nSteps,
        NumericVector the_shift,
        NumericVector the_sigma,
        NumericMatrix the_rho,
        NumericMatrix the_scaled_pc,
        int the_dt,
        int the_bundBegin, int the_bundEnd,
        int the_swapBegin, int the_swapEnd,
        int the_realBegin, int the_realEnd
    ):
    L0(the_L0), nSteps(the_nSteps), shift(the_shift), sigma(the_sigma),
    rho(the_rho), scaled_pc(the_scaled_pc), dt(the_dt),
    bundBegin(the_bundBegin), bundEnd(the_bundEnd),
    swapBegin(the_swapBegin), swapEnd(the_swapEnd),
    realBegin(the_realBegin), realEnd(the_realEnd)
    {}
    

public:

    virtual ~PathGenerator(){}             // make virtual!!
    virtual NumericMatrix nextPath() = 0;
    /** Size of time step in days.
     */
    int getTimeStepSize(){ return dt; }
};


class GeometricRiskNeutralPathGenerator : public PathGenerator  {

public:
    GeometricRiskNeutralPathGenerator(
        NumericVector L0,
        int nSteps,
        NumericVector shift,
        NumericVector sigma,
        NumericMatrix rho,
        NumericMatrix scaled_pc,
        int dt,
        int bundBegin, int bundEnd,
        int swapBegin, int swapEnd,
        int realBegin, int realEnd
    ):
    PathGenerator(
        L0,nSteps,shift,sigma,rho,scaled_pc,dt,
        bundBegin,bundEnd,swapBegin,swapEnd,realBegin,realEnd
    )
    {}

    NumericMatrix nextPath(){

        return nextGeometricRiskNeutralPath(
           L0,nSteps,shift,sigma,rho,scaled_pc,dt,
           bundBegin,bundEnd,swapBegin,swapEnd,realBegin,realEnd
        );
     }
};



class HybridModelPathGenerator : public PathGenerator  {

private:
    NumericVector kappa;

public:
    HybridModelPathGenerator(
        NumericVector the_kappa,
        NumericVector L0,
        int nSteps,
        NumericVector shift,
        NumericVector sigma,
        NumericMatrix rho,
        NumericMatrix scaled_pc,
        int dt,
        int bundBegin, int bundEnd,
        int swapBegin, int swapEnd,
        int realBegin, int realEnd
    ):
    PathGenerator(
        L0,nSteps,shift,sigma,rho,scaled_pc,dt,
        bundBegin,bundEnd,swapBegin,swapEnd,realBegin,realEnd
    ),
    kappa(the_kappa)
    {}

    NumericMatrix nextPath(){

        return nextHybridPath(
           kappa,L0,nSteps,shift,sigma,rho,scaled_pc,dt,
           bundBegin,bundEnd,swapBegin,swapEnd,realBegin,realEnd
        );
     }
};


/** Returns a PathGenerator of specified type with 30 day time steps
 *  until the first time point past the end of numQuarter quarters.
 *
 * @param pathType: "geometricRiskNeutral", "hybrid".
 *
 */
PathGenerator*  makePathGenerator(
   string pathType,
   int nPath, int numQuarters,
   NumericVector kappa,
   NumericVector L0,
   NumericVector shift,
   NumericVector sigma,
   NumericMatrix rho,
   NumericMatrix scaled_pc,
   int bundBegin, int bundEnd,
   int swapBegin, int swapEnd,
   int realBegin, int realEnd
);


#endif