#include <Rcpp.h>
#include <cmath>
#include "matrix.hpp"

using namespace Rcpp;

// This file defines the C++ kernels for path computation of the Libor market
// model in the forward martingale measure at the simulation horizon.






//============================ Lognormal Paths ===============================//


// Computes one lognormal path of a discrete forward curve under the forward
// martingale measure at the simulation horizon.
// The maturity grid of the forward curve is assumed to be regular of with
// a mesh width equal to the length dt of the time steps of the simulation.
//
// Our volas and PCs are for annualized Libors, so here we get paths of
// forward curves with annualized Libors also!
// Moreover the volas are scaled to time steps of one year as usual so we need
// to multiply with sqrt(dt) in each time step.
//
// @param L0 unshited starting Libor curve, absolute rates.
// @param shift shift value to be applied to every libor
//
// @param scaled_pc matrix of principal components of the
// covariance matrix scaled with the eigenvalues (for simulation):
//     col_j(lambda_pc) = sqrt(lambda_j)* pc_j,
// where pc_j denotes the j-th principal component of the covariance matrix
// of the Libor increments and lambda_j the corresponding eigenvalue of the
// covariance matrix.
//
// @param sigma vector of log-Libor vols.
// @param dt size of time step in years.
// @param bundBegin: first (zero based) index of BUND libors in the full
// Libor curve of the multimarket
// @param bundEnd: one past the last (zero based) index of BUND libors in the
// full Libor curve of the multimarket
//
// If the forward path has no BUND curves, set bundBegin=bundEnd (e.g.: = 0)
// Similarly if there are no REAL curves.
// This is determined by the covariance matrix and its principal components.
//
// @return matrix of libor curves along the time steps of the path,
// row_j contains the libor curve after time step j, row_0 is the starting
// curve.
//
// [[Rcpp::export]]
NumericMatrix
nextGeometricRiskNeutralPath(
        NumericVector L0,
        int nSteps,
        NumericVector shift,
        NumericVector sigma,
        NumericMatrix rho,
        NumericMatrix scaled_pc,
        int dt,
        int bundBegin,
        int bundEnd,
        int swapBegin,
        int swapEnd,
        int realBegin,
        int realEnd
){
    double dT = dt/365.25;
    double sqrt_dT = sqrt(dT);
    int nLibors = L0.size();
    int numPCs = scaled_pc.ncol();

    // Columns contain the unshifted Libor curves in temporal order starting
    // with the start curve
    NumericMatrix X(1+nSteps,nLibors);
    X(0, _) = L0;

    // recall: shift is negative
    NumericVector L(L0-shift);     // current Libor curve, starts with L0+shift
    NumericVector y = log(L);

    // development of the log-libor curves y, y_next
    for(int i=0;i<nSteps;i++){

        NumericVector y_next(nLibors);
        NumericVector Z = rnorm(numPCs);
        NumericVector vola_increment = sqrt_dT*mv_mult(scaled_pc,Z);
        // drift increment, 12.0: L_j needs to be multiplied with delta_j = 1/12
        NumericVector drift_increment(nLibors);
        for(int j=0;j<nLibors;j++)
           for(int k=j+1;k<nLibors;k++)
              drift_increment[j] -= sigma[j]*sigma[k]*rho(j,k)*L[k]/(12.0+L[k]);
        drift_increment = drift_increment -0.5*sigma*sigma;
        drift_increment = dT*drift_increment;

        y_next = y+drift_increment+vola_increment;
        y = y_next;             // shifted log-libors
        L = exp(y);              // shifted libors
        X(1+i, _) = L+shift;
    }
    // FIX ME: the shift has to occur in each segment of the curve:
    // BUND, SWAP, REAL
    // shift the expired Libors at the beginning of each curve off with
    // constant extension at the end
    for(int i=1;i<=nSteps;++i){
    
       // at step i the first i Libors of each curve have expired
       // and need to be shifted off
       // BUND
       for(int j=bundBegin;j<bundEnd-i;++j) X(i,j)=X(i,j+i);
       for(int j=bundEnd-i;j<bundEnd;++j) X(i,j)=X(i,bundEnd-1);
       // SWAP
       for(int j=swapBegin;j<swapEnd-i;++j) X(i,j)=X(i,j+i);
       for(int j=swapEnd-i;j<swapEnd;++j) X(i,j)=X(i,swapEnd-1);
       // REAL
       for(int j=realBegin;j<realEnd-i;++j) X(i,j)=X(i,j+i);
       for(int j=realEnd-i;j<realEnd;++j) X(i,j)=X(i,realEnd-1);
    }
    return(X);
}






NumericMatrix
nextHybridPath(
        NumericVector kappa,
        NumericVector L0,
        int nSteps,
        NumericVector shift,
        NumericVector sigma,
        NumericMatrix rho,
        NumericMatrix scaled_pc,
        int dt,
        int bundBegin,
        int bundEnd,
        int swapBegin,
        int swapEnd,
        int realBegin,
        int realEnd
){
    double dT = dt/365.25;
    double sqrt_dT = sqrt(dT);
    int nLibors = L0.size();
    int numPCs = scaled_pc.ncol();

    // Columns contain the unshifted Libor curves in temporal order starting
    // with the start curve
    NumericMatrix X(1+nSteps,nLibors);
    X(0, _) = L0;

    // recall: shift is negative
    NumericVector L(L0-shift);     // current Libor curve, starts with L0+shift
    NumericVector y = log(L);

    // development of the log-libor curves y, y_next
    for(int i=0;i<nSteps;i++){

        L = exp(y);              // shifted libors
        NumericVector y_next(nLibors);
        NumericVector Z = rnorm(numPCs);
        // hybrid vola increment of log-Libors,
        // still needs to be divided by w in loop below
        NumericVector vola_increment = sqrt_dT*mv_mult(scaled_pc,Z);
        // hybrid drift increment of log-Libors
        NumericVector drift_increment(nLibors);
        for(int j=0;j<nLibors;j++){
        
           int k;    // forward mode with constant extension at the end
           if(j<nLibors-1) k=j+1; else k=j;
           double w = L[k]+kappa[k];
           vola_increment[j] /= w;
           drift_increment[j] = -0.5*dT*sigma[j]*sigma[j]/(w*w);
        }
        y_next = y+drift_increment+vola_increment;
        y = y_next;             // shifted log-libors
        X(1+i, _) = L+shift;
    }
    // FIX ME: the shift has to occur in each segment of the curve:
    // BUND, SWAP, REAL
    // shift the expired Libors at the beginning of each curve off with
    // constant extension at the end
    for(int i=1;i<=nSteps;++i){

       // at step i the first i Libors of each curve have expired
       // and need to be shifted off
       // BUND
       for(int j=bundBegin;j<bundEnd-i;++j) X(i,j)=X(i,j+i);
       for(int j=bundEnd-i;j<bundEnd;++j) X(i,j)=X(i,bundEnd-1);
       // SWAP
       for(int j=swapBegin;j<swapEnd-i;++j) X(i,j)=X(i,j+i);
       for(int j=swapEnd-i;j<swapEnd;++j) X(i,j)=X(i,swapEnd-1);
       // REAL
       for(int j=realBegin;j<realEnd-i;++j) X(i,j)=X(i,j+i);
       for(int j=realEnd-i;j<realEnd;++j) X(i,j)=X(i,realEnd-1);
    }
    return(X);
}


