
#ifndef a1b2c3__matrix_h
#define a1b2c3__matrix_h

#include <Rcpp.h>
using Rcpp::NumericMatrix;
using Rcpp::NumericVector;

NumericMatrix emptyMatrix();
NumericMatrix diagMatrix(const NumericVector& d);
NumericMatrix transpose(const NumericMatrix& A);
NumericVector mv_mult(const NumericMatrix& A, const NumericVector& x);
NumericMatrix mm_mult(const NumericMatrix& A, const NumericMatrix& B);
// A*diag(d)
NumericMatrix mm_rightmult_diag(const NumericMatrix& A, const NumericVector& d);
// diag(d)*A*diag(d)
NumericMatrix mm_bimult_diag(const NumericMatrix& A, const NumericVector& d);
void printVector(const NumericVector& vec,int precision);
void printMatrix(const NumericMatrix& A,int precision);

#endif

