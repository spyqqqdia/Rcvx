#include "swapprogram.hpp"



/** Number of float periods (180 days) of a swap with maturity index m
 *  (index in swap weight vector):
 *  m==0 --> maturity = 2Y, ..., m==6 --> maturity = 30Y
 */
int numSwapFloatPeriods(int m){

   if(m==0) return 4;           // maturity = 2Y
   // m=1,2,3,4,5,6 ---> maturity = 5,10,15,20,25,30   years
   //               ---> periods = 10,20,30,40,50,60
   return 10*m;
}


vector<Swap> swapList(int numQuarters, NumericMatrix swapprogram){

   vector<Swap> result;
   result.reserve(numQuarters*7*12);

   for(int j=0;j<numQuarters;j++){

      NumericVector swapWeights = swapprogram(j, _);  // swap weights in rows
      // iterate over the maturities
      for (int m=0; m<7; m++){

         double w = swapWeights[m];
         // distribute swap allocation over the 12 weeks in quarter j
         for (int k=0; k<12; k++){

            double nominal = w/12;
            int startDate = j*90+k*7;  // days from refDate
            int nPeriods = numSwapFloatPeriods(m);
            Swap sw(nominal,startDate,nPeriods);
            result.push_back(sw);
        }
      }
    }
    return result;
}




// [[Rcpp::export]]
NumericMatrix binnedSwapCFs(
   const NumericMatrix& swapprogram,
   string pathType, int nPath, int numQuarters,
   NumericVector kappa,
   NumericVector L0,              // initial swap curve
   NumericVector shift,
   NumericVector sigma,
   NumericMatrix rho,
   NumericMatrix scaled_pc
){
    // paramaters for forward path generation: we have only the swap market,
    // no BUND or REAL curves
    int bundBegin=0; int bundEnd=0;
    int realBegin=0; int realEnd=0;
    int swapBegin=0; int swapEnd = L0.size();

    PathGenerator* pg = makePathGenerator(
       pathType,nPath,numQuarters,kappa,L0,shift,sigma,rho,scaled_pc,
       bundBegin,bundEnd,swapBegin,swapEnd,realBegin,realEnd
    );
    NumericMatrix CF(nPath,numQuarters);

    // fixed rates set to NaN!!
    vector<Swap> theSwaps = swapList(numQuarters,swapprogram);

    for(int i = 0;i<nPath;i++){

       NumericMatrix forwardPath = pg->nextPath();
       for(Swap sw: theSwaps){

          // bin the Cfs of this swap
          int startDate = sw.getStartDate();
          int nPeriods = sw.getNumPeriods();
          double nominal = sw.getNominal();
          int dt = pg -> getTimeStepSize();
          double fixedRate = sw.fixedRate(dt,forwardPath);
          for(int j=1;j<nPeriods;j++){

             int t = startDate+j*180;        // pay day of cash flow
             if(t < 90*numQuarters) {        // CF pays before end of last quarter

                // now t/dt < nSteps-1
                int q = t/90;                // number of quarter in which CF pays
                // float CF
                double L6M = libor6M_at_date(t,dt,forwardPath);   // nonannualized
                CF(i,q) -= nominal*L6M;      // receive float CF

                // pay fixed CF only annually
                if(j%2==0) CF(i,q) += nominal*fixedRate;

             } // end if
          }  // end for j = numPeriod
       }  // end for sw
    } // end for i = numPath
    delete pg;
    return CF;
}

