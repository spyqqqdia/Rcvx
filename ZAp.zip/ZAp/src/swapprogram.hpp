#ifndef zzwwv_swapprogram_h
#define zzwwv_swapprogram_h

#include "swap.hpp"
#include "utils.hpp"
#include "PathGenerator.hpp"
#include <Rcpp.h>
#include <vector>
#include <string>
using Rcpp::NumericMatrix;
using Rcpp::NumericVector;
using Rcpp::_;
using std::vector;
using std::string;





/** Returns the list of swaps allocated in all quarters by spreading the given
 *  swap weights evenly over the 12 weeks in the quarter.
 *
 * @param swapWeights: volumes for the seven maturities 2Y-30Y to be allocated
 * in the quarter.
 *
 * Swaps are allocated independent of forward path with _fixedRate = NaN.
 * The fixed rate then has to be set separately for each forward path.
 */
vector<Swap> swapList(int numQuarters, NumericMatrix swapprogram);




/** Returns the matrix CF of swap CFs for the entire swap-program binned by
 *  quarter, where
 *    CF[i,j] is the sum of swap CFs in quarter j along forwardPath i.
 *  The forward paths are generated dynamically and discarded after the
 *  cashflows have been binned.
 *
 * @param swapprogram: an nx7 matrix where row j contains the volumes of swaps
 * in maturities 2Y,5Y,10Y,15Y,20Y,25Y,30Y to be allocated in quarter j.
 * These volumes are then spread evenly over the 12 weeks in each qaurter.
 *
 * @param L0: start curve for swap market (swap curve at refDate).
 * @param shift: shift value applied to swap curve
 * @param sigam: vector of swap Libor vols
 * @param rho: correlation matrix of swap Libors
 * @param scaled_pc: matrix of principal components of the
 * covariance matrix scaled with the eigenvalues (for simulation):
 *    col_j(lambda_pc) = sqrt(lambda_j)* pc_j,
 * where pc_j denotes the j-th principal component of the covariance matrix
 * of the Libor increments and lambda_j the corresponding eigenvalue of the
 * covariance matrix.
 *
 */
// [[Rcpp::export]]
NumericMatrix binnedSwapCFs(
   const NumericMatrix& swapprogram,
   string pathType, int nPath, int numQuarters,
   NumericVector kappa,
   NumericVector L0,
   NumericVector shift,
   NumericVector sigma,
   NumericMatrix rho,
   NumericMatrix scaled_pc
);


















#endif